; ModuleID = 'opts-common.c'
source_filename = "opts-common.c"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-pc-linux-gnu"

%struct.cl_option = type { ptr, ptr, i16, i8, i32, i32, ptr, i32, i32 }
%struct._IO_FILE = type { i32, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, ptr, i32, i32, i64, i16, i8, [1 x i8], ptr, i64, ptr, ptr, ptr, ptr, i64, i32, [20 x i8] }

@stdout = external local_unnamed_addr global ptr, align 8
@stdin = external local_unnamed_addr global ptr, align 8
@cl_options_count = external local_unnamed_addr constant i32, align 4
@cl_options = external local_unnamed_addr constant [0 x %struct.cl_option], align 8

; Function Attrs: cold inlinehint nofree nounwind uwtable
define dso_local noundef i32 @vprintf(ptr noalias nocapture noundef readonly %0, ptr noundef %1) local_unnamed_addr #0 !prof !37 {
  %3 = load ptr, ptr @stdout, align 8, !tbaa !38
  %4 = tail call i32 @vfprintf(ptr noundef %3, ptr noundef %0, ptr noundef %1)
  ret i32 %4
}

; Function Attrs: nofree nounwind
declare noundef i32 @vfprintf(ptr nocapture noundef, ptr nocapture noundef readonly, ptr noundef) local_unnamed_addr #1

; Function Attrs: cold inlinehint nofree nounwind uwtable
define dso_local noundef i32 @getchar() local_unnamed_addr #0 !prof !37 {
  %1 = load ptr, ptr @stdin, align 8, !tbaa !38
  %2 = tail call i32 @getc(ptr noundef %1)
  ret i32 %2
}

; Function Attrs: nofree nounwind
declare noundef i32 @getc(ptr nocapture noundef) local_unnamed_addr #1

; Function Attrs: cold inlinehint nounwind uwtable
define dso_local i32 @fgetc_unlocked(ptr noundef %0) local_unnamed_addr #2 !prof !37 {
  %2 = getelementptr inbounds %struct._IO_FILE, ptr %0, i64 0, i32 1
  %3 = load ptr, ptr %2, align 8, !tbaa !42
  %4 = getelementptr inbounds %struct._IO_FILE, ptr %0, i64 0, i32 2
  %5 = load ptr, ptr %4, align 8, !tbaa !47
  %6 = icmp ult ptr %3, %5
  br i1 %6, label %9, label %7, !prof !48

7:                                                ; preds = %1
  %8 = tail call i32 @__uflow(ptr noundef %0) #14
  br label %13

9:                                                ; preds = %1
  %10 = getelementptr inbounds i8, ptr %3, i64 1
  store ptr %10, ptr %2, align 8, !tbaa !42
  %11 = load i8, ptr %3, align 1, !tbaa !49
  %12 = zext i8 %11 to i32
  br label %13

13:                                               ; preds = %9, %7
  %14 = phi i32 [ %8, %7 ], [ %12, %9 ]
  ret i32 %14
}

declare i32 @__uflow(ptr noundef) local_unnamed_addr #3

; Function Attrs: cold inlinehint nounwind uwtable
define dso_local i32 @getc_unlocked(ptr noundef %0) local_unnamed_addr #2 !prof !37 {
  %2 = getelementptr inbounds %struct._IO_FILE, ptr %0, i64 0, i32 1
  %3 = load ptr, ptr %2, align 8, !tbaa !42
  %4 = getelementptr inbounds %struct._IO_FILE, ptr %0, i64 0, i32 2
  %5 = load ptr, ptr %4, align 8, !tbaa !47
  %6 = icmp ult ptr %3, %5
  br i1 %6, label %9, label %7, !prof !48

7:                                                ; preds = %1
  %8 = tail call i32 @__uflow(ptr noundef %0) #14
  br label %13

9:                                                ; preds = %1
  %10 = getelementptr inbounds i8, ptr %3, i64 1
  store ptr %10, ptr %2, align 8, !tbaa !42
  %11 = load i8, ptr %3, align 1, !tbaa !49
  %12 = zext i8 %11 to i32
  br label %13

13:                                               ; preds = %9, %7
  %14 = phi i32 [ %8, %7 ], [ %12, %9 ]
  ret i32 %14
}

; Function Attrs: cold inlinehint nounwind uwtable
define dso_local i32 @getchar_unlocked() local_unnamed_addr #2 !prof !37 {
  %1 = load ptr, ptr @stdin, align 8, !tbaa !38
  %2 = getelementptr inbounds %struct._IO_FILE, ptr %1, i64 0, i32 1
  %3 = load ptr, ptr %2, align 8, !tbaa !42
  %4 = getelementptr inbounds %struct._IO_FILE, ptr %1, i64 0, i32 2
  %5 = load ptr, ptr %4, align 8, !tbaa !47
  %6 = icmp ult ptr %3, %5
  br i1 %6, label %9, label %7, !prof !48

7:                                                ; preds = %0
  %8 = tail call i32 @__uflow(ptr noundef %1) #14
  br label %13

9:                                                ; preds = %0
  %10 = getelementptr inbounds i8, ptr %3, i64 1
  store ptr %10, ptr %2, align 8, !tbaa !42
  %11 = load i8, ptr %3, align 1, !tbaa !49
  %12 = zext i8 %11 to i32
  br label %13

13:                                               ; preds = %9, %7
  %14 = phi i32 [ %8, %7 ], [ %12, %9 ]
  ret i32 %14
}

; Function Attrs: cold inlinehint nofree nounwind uwtable
define dso_local noundef i32 @putchar(i32 noundef %0) local_unnamed_addr #0 !prof !37 {
  %2 = load ptr, ptr @stdout, align 8, !tbaa !38
  %3 = tail call i32 @putc(i32 noundef %0, ptr noundef %2)
  ret i32 %3
}

; Function Attrs: nofree nounwind
declare noundef i32 @putc(i32 noundef, ptr nocapture noundef) local_unnamed_addr #1

; Function Attrs: cold inlinehint nounwind uwtable
define dso_local i32 @fputc_unlocked(i32 noundef %0, ptr noundef %1) local_unnamed_addr #2 !prof !37 {
  %3 = getelementptr inbounds %struct._IO_FILE, ptr %1, i64 0, i32 5
  %4 = load ptr, ptr %3, align 8, !tbaa !50
  %5 = getelementptr inbounds %struct._IO_FILE, ptr %1, i64 0, i32 6
  %6 = load ptr, ptr %5, align 8, !tbaa !51
  %7 = icmp ult ptr %4, %6
  br i1 %7, label %11, label %8, !prof !48

8:                                                ; preds = %2
  %9 = and i32 %0, 255
  %10 = tail call i32 @__overflow(ptr noundef %1, i32 noundef %9) #14
  br label %15

11:                                               ; preds = %2
  %12 = trunc i32 %0 to i8
  %13 = getelementptr inbounds i8, ptr %4, i64 1
  store ptr %13, ptr %3, align 8, !tbaa !50
  store i8 %12, ptr %4, align 1, !tbaa !49
  %14 = and i32 %0, 255
  br label %15

15:                                               ; preds = %11, %8
  %16 = phi i32 [ %10, %8 ], [ %14, %11 ]
  ret i32 %16
}

declare i32 @__overflow(ptr noundef, i32 noundef) local_unnamed_addr #3

; Function Attrs: cold inlinehint nounwind uwtable
define dso_local i32 @putc_unlocked(i32 noundef %0, ptr noundef %1) local_unnamed_addr #2 !prof !37 {
  %3 = getelementptr inbounds %struct._IO_FILE, ptr %1, i64 0, i32 5
  %4 = load ptr, ptr %3, align 8, !tbaa !50
  %5 = getelementptr inbounds %struct._IO_FILE, ptr %1, i64 0, i32 6
  %6 = load ptr, ptr %5, align 8, !tbaa !51
  %7 = icmp ult ptr %4, %6
  br i1 %7, label %11, label %8, !prof !48

8:                                                ; preds = %2
  %9 = and i32 %0, 255
  %10 = tail call i32 @__overflow(ptr noundef %1, i32 noundef %9) #14
  br label %15

11:                                               ; preds = %2
  %12 = trunc i32 %0 to i8
  %13 = getelementptr inbounds i8, ptr %4, i64 1
  store ptr %13, ptr %3, align 8, !tbaa !50
  store i8 %12, ptr %4, align 1, !tbaa !49
  %14 = and i32 %0, 255
  br label %15

15:                                               ; preds = %11, %8
  %16 = phi i32 [ %10, %8 ], [ %14, %11 ]
  ret i32 %16
}

; Function Attrs: cold inlinehint nounwind uwtable
define dso_local i32 @putchar_unlocked(i32 noundef %0) local_unnamed_addr #2 !prof !37 {
  %2 = load ptr, ptr @stdout, align 8, !tbaa !38
  %3 = getelementptr inbounds %struct._IO_FILE, ptr %2, i64 0, i32 5
  %4 = load ptr, ptr %3, align 8, !tbaa !50
  %5 = getelementptr inbounds %struct._IO_FILE, ptr %2, i64 0, i32 6
  %6 = load ptr, ptr %5, align 8, !tbaa !51
  %7 = icmp ult ptr %4, %6
  br i1 %7, label %11, label %8, !prof !48

8:                                                ; preds = %1
  %9 = and i32 %0, 255
  %10 = tail call i32 @__overflow(ptr noundef %2, i32 noundef %9) #14
  br label %15

11:                                               ; preds = %1
  %12 = trunc i32 %0 to i8
  %13 = getelementptr inbounds i8, ptr %4, i64 1
  store ptr %13, ptr %3, align 8, !tbaa !50
  store i8 %12, ptr %4, align 1, !tbaa !49
  %14 = and i32 %0, 255
  br label %15

15:                                               ; preds = %11, %8
  %16 = phi i32 [ %10, %8 ], [ %14, %11 ]
  ret i32 %16
}

; Function Attrs: cold inlinehint nounwind uwtable
define dso_local i64 @getline(ptr noundef %0, ptr noundef %1, ptr noundef %2) local_unnamed_addr #2 !prof !37 {
  %4 = tail call i64 @__getdelim(ptr noundef %0, ptr noundef %1, i32 noundef 10, ptr noundef %2) #14
  ret i64 %4
}

declare i64 @__getdelim(ptr noundef, ptr noundef, i32 noundef, ptr noundef) local_unnamed_addr #3

; Function Attrs: cold inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i32 @feof_unlocked(ptr nocapture noundef readonly %0) local_unnamed_addr #4 !prof !37 {
  %2 = load i32, ptr %0, align 8, !tbaa !52
  %3 = lshr i32 %2, 4
  %4 = and i32 %3, 1
  ret i32 %4
}

; Function Attrs: cold inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i32 @ferror_unlocked(ptr nocapture noundef readonly %0) local_unnamed_addr #4 !prof !37 {
  %2 = load i32, ptr %0, align 8, !tbaa !52
  %3 = lshr i32 %2, 5
  %4 = and i32 %3, 1
  ret i32 %4
}

; Function Attrs: cold inlinehint mustprogress nofree nounwind willreturn memory(read) uwtable
define dso_local i32 @tolower(i32 noundef %0) local_unnamed_addr #5 !prof !37 {
  %2 = add i32 %0, 128
  %3 = icmp ult i32 %2, 384
  br i1 %3, label %4, label %10

4:                                                ; preds = %1
  %5 = tail call ptr @__ctype_tolower_loc() #14
  %6 = load ptr, ptr %5, align 8, !tbaa !38
  %7 = sext i32 %0 to i64
  %8 = getelementptr inbounds i32, ptr %6, i64 %7
  %9 = load i32, ptr %8, align 4, !tbaa !53
  br label %10

10:                                               ; preds = %1, %4
  %11 = phi i32 [ %9, %4 ], [ %0, %1 ]
  ret i32 %11
}

declare ptr @__ctype_tolower_loc() local_unnamed_addr #3

; Function Attrs: cold inlinehint mustprogress nofree nounwind willreturn memory(read) uwtable
define dso_local i32 @toupper(i32 noundef %0) local_unnamed_addr #5 !prof !37 {
  %2 = add i32 %0, 128
  %3 = icmp ult i32 %2, 384
  br i1 %3, label %4, label %10

4:                                                ; preds = %1
  %5 = tail call ptr @__ctype_toupper_loc() #14
  %6 = load ptr, ptr %5, align 8, !tbaa !38
  %7 = sext i32 %0 to i64
  %8 = getelementptr inbounds i32, ptr %6, i64 %7
  %9 = load i32, ptr %8, align 4, !tbaa !53
  br label %10

10:                                               ; preds = %1, %4
  %11 = phi i32 [ %9, %4 ], [ %0, %1 ]
  ret i32 %11
}

declare ptr @__ctype_toupper_loc() local_unnamed_addr #3

; Function Attrs: cold inlinehint mustprogress nofree nounwind willreturn uwtable
define dso_local i32 @atoi(ptr nocapture noundef readonly %0) local_unnamed_addr #6 !prof !37 {
  %2 = tail call i64 @strtol(ptr nocapture noundef %0, ptr noundef null, i32 noundef 10)
  %3 = trunc i64 %2 to i32
  ret i32 %3
}

; Function Attrs: mustprogress nofree nounwind willreturn
declare i64 @strtol(ptr noundef readonly, ptr nocapture noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: cold inlinehint mustprogress nofree nounwind willreturn uwtable
define dso_local i64 @atol(ptr nocapture noundef readonly %0) local_unnamed_addr #6 !prof !37 {
  %2 = tail call i64 @strtol(ptr nocapture noundef %0, ptr noundef null, i32 noundef 10)
  ret i64 %2
}

; Function Attrs: cold inlinehint mustprogress nofree nounwind willreturn uwtable
define dso_local i64 @atoll(ptr nocapture noundef readonly %0) local_unnamed_addr #6 !prof !37 {
  %2 = tail call i64 @strtoll(ptr nocapture noundef %0, ptr noundef null, i32 noundef 10)
  ret i64 %2
}

; Function Attrs: mustprogress nofree nounwind willreturn
declare i64 @strtoll(ptr noundef readonly, ptr nocapture noundef, i32 noundef) local_unnamed_addr #7

; Function Attrs: cold inlinehint nounwind uwtable
define dso_local noundef ptr @bsearch(ptr noundef %0, ptr noundef %1, i64 noundef %2, i64 noundef %3, ptr nocapture noundef readonly %4) local_unnamed_addr #2 !prof !37 {
  %6 = icmp eq i64 %2, 0
  br i1 %6, label %24, label %7

7:                                                ; preds = %5, %20
  %8 = phi i64 [ %22, %20 ], [ 0, %5 ]
  %9 = phi i64 [ %21, %20 ], [ %2, %5 ]
  %10 = add i64 %8, %9
  %11 = lshr i64 %10, 1
  %12 = mul i64 %11, %3
  %13 = getelementptr inbounds i8, ptr %1, i64 %12
  %14 = tail call i32 %4(ptr noundef %0, ptr noundef %13) #14
  %15 = icmp slt i32 %14, 0
  br i1 %15, label %20, label %16

16:                                               ; preds = %7
  %17 = icmp eq i32 %14, 0
  br i1 %17, label %24, label %18

18:                                               ; preds = %16
  %19 = add nuw i64 %11, 1
  br label %20

20:                                               ; preds = %7, %18
  %21 = phi i64 [ %9, %18 ], [ %11, %7 ]
  %22 = phi i64 [ %19, %18 ], [ %8, %7 ]
  %23 = icmp ult i64 %22, %21
  br i1 %23, label %7, label %24, !llvm.loop !54

24:                                               ; preds = %16, %20, %5
  %25 = phi ptr [ null, %5 ], [ %13, %16 ], [ null, %20 ]
  ret ptr %25
}

; Function Attrs: cold inlinehint mustprogress nofree nounwind willreturn uwtable
define dso_local double @atof(ptr nocapture noundef readonly %0) local_unnamed_addr #6 !prof !37 {
  %2 = tail call double @strtod(ptr nocapture noundef %0, ptr noundef null)
  ret double %2
}

; Function Attrs: mustprogress nofree nounwind willreturn
declare double @strtod(ptr noundef readonly, ptr nocapture noundef) local_unnamed_addr #7

; Function Attrs: nofree nounwind memory(read, inaccessiblemem: none) uwtable
define dso_local i64 @find_opt(ptr nocapture noundef readonly %0, i32 noundef %1) local_unnamed_addr #8 !prof !57 {
  %3 = load i32, ptr @cl_options_count, align 4, !tbaa !53
  %4 = zext i32 %3 to i64
  %5 = icmp ugt i32 %3, 1
  br i1 %5, label %6, label %23, !prof !58

6:                                                ; preds = %2, %6
  %7 = phi i64 [ %20, %6 ], [ 0, %2 ]
  %8 = phi i64 [ %19, %6 ], [ %4, %2 ]
  %9 = add i64 %7, %8
  %10 = lshr i64 %9, 1
  %11 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %10
  %12 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %10, i32 3
  %13 = load i8, ptr %12, align 2, !tbaa !59
  %14 = zext i8 %13 to i64
  %15 = load ptr, ptr %11, align 8, !tbaa !61
  %16 = getelementptr inbounds i8, ptr %15, i64 1
  %17 = tail call i32 @strncmp(ptr noundef %0, ptr noundef nonnull %16, i64 noundef %14)
  %18 = icmp slt i32 %17, 0
  %19 = select i1 %18, i64 %10, i64 %8, !prof !62
  %20 = select i1 %18, i64 %7, i64 %10, !prof !62
  %21 = sub i64 %19, %20
  %22 = icmp ugt i64 %21, 1
  br i1 %22, label %6, label %23, !prof !63, !llvm.loop !64

23:                                               ; preds = %6, %2
  %24 = phi i64 [ 0, %2 ], [ %20, %6 ]
  br label %25

25:                                               ; preds = %23, %64
  %26 = phi i64 [ %60, %64 ], [ %4, %23 ]
  %27 = phi i64 [ %61, %64 ], [ %24, %23 ]
  %28 = phi i64 [ %62, %64 ], [ undef, %23 ]
  %29 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %27
  %30 = load ptr, ptr %29, align 8, !tbaa !61
  %31 = getelementptr inbounds i8, ptr %30, i64 1
  %32 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %27, i32 3
  %33 = load i8, ptr %32, align 2, !tbaa !59
  %34 = zext i8 %33 to i64
  %35 = tail call i32 @strncmp(ptr noundef %0, ptr noundef nonnull %31, i64 noundef %34)
  %36 = icmp eq i32 %35, 0
  br i1 %36, label %37, label %54, !prof !65

37:                                               ; preds = %25
  %38 = getelementptr inbounds i8, ptr %0, i64 %34
  %39 = load i8, ptr %38, align 1, !tbaa !49
  %40 = icmp eq i8 %39, 0
  br i1 %40, label %46, label %41, !prof !66

41:                                               ; preds = %37
  %42 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %27, i32 5
  %43 = load i32, ptr %42, align 8, !tbaa !67
  %44 = and i32 %43, 33554432
  %45 = icmp eq i32 %44, 0
  br i1 %45, label %54, label %46, !prof !68

46:                                               ; preds = %41, %37
  %47 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %27, i32 5
  %48 = load i32, ptr %47, align 8, !tbaa !67
  %49 = and i32 %48, %1
  %50 = icmp eq i32 %49, 0
  br i1 %50, label %51, label %59, !prof !69

51:                                               ; preds = %46
  %52 = icmp eq i64 %26, %4
  %53 = select i1 %52, i64 %27, i64 %26
  br label %54

54:                                               ; preds = %51, %41, %25
  %55 = phi i64 [ %26, %25 ], [ %26, %41 ], [ %53, %51 ]
  %56 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %27, i32 2
  %57 = load i16, ptr %56, align 8, !tbaa !70
  %58 = zext i16 %57 to i64
  br label %59

59:                                               ; preds = %46, %54
  %60 = phi i64 [ %55, %54 ], [ %26, %46 ]
  %61 = phi i64 [ %58, %54 ], [ %27, %46 ]
  %62 = phi i64 [ %28, %54 ], [ %27, %46 ]
  %63 = phi i1 [ true, %54 ], [ false, %46 ]
  br i1 %63, label %64, label %66, !prof !69

64:                                               ; preds = %59
  %65 = icmp eq i64 %61, %4
  br i1 %65, label %66, label %25, !llvm.loop !71

66:                                               ; preds = %64, %59
  %67 = phi i64 [ %62, %59 ], [ %60, %64 ]
  ret i64 %67
}

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare i32 @strncmp(ptr nocapture noundef, ptr nocapture noundef, i64 noundef) local_unnamed_addr #9

; Function Attrs: cold nounwind uwtable
define dso_local void @prune_options(ptr nocapture noundef %0, ptr nocapture noundef %1) local_unnamed_addr #10 !prof !37 {
  %3 = load i32, ptr %0, align 4, !tbaa !53
  %4 = sext i32 %3 to i64
  %5 = shl nsw i64 %4, 2
  %6 = tail call ptr @xmalloc(i64 noundef %5) #14
  %7 = shl nsw i64 %4, 3
  %8 = tail call ptr @xmalloc(i64 noundef %7) #14
  %9 = icmp sgt i32 %3, 1
  br i1 %9, label %10, label %124

10:                                               ; preds = %2
  %11 = load i32, ptr @cl_options_count, align 4
  %12 = zext i32 %11 to i64
  %13 = zext nneg i32 %3 to i64
  br label %14

14:                                               ; preds = %10, %70
  %15 = phi i64 [ 1, %10 ], [ %72, %70 ]
  %16 = phi i32 [ 0, %10 ], [ %71, %70 ]
  %17 = load ptr, ptr %1, align 8, !tbaa !38
  %18 = getelementptr inbounds ptr, ptr %17, i64 %15
  %19 = load ptr, ptr %18, align 8, !tbaa !38
  %20 = getelementptr inbounds i8, ptr %19, i64 1
  %21 = tail call i64 @find_opt(ptr noundef nonnull %20, i32 noundef -1)
  %22 = icmp eq i64 %21, %12
  br i1 %22, label %23, label %47

23:                                               ; preds = %14
  %24 = load i8, ptr %20, align 1, !tbaa !49
  switch i8 %24, label %47 [
    i8 87, label %25
    i8 102, label %25
    i8 109, label %25
  ]

25:                                               ; preds = %23, %23, %23
  %26 = getelementptr inbounds i8, ptr %19, i64 2
  %27 = load i8, ptr %26, align 1, !tbaa !49
  %28 = icmp eq i8 %27, 110
  br i1 %28, label %29, label %47

29:                                               ; preds = %25
  %30 = getelementptr inbounds i8, ptr %19, i64 3
  %31 = load i8, ptr %30, align 1, !tbaa !49
  %32 = icmp eq i8 %31, 111
  br i1 %32, label %33, label %47

33:                                               ; preds = %29
  %34 = getelementptr inbounds i8, ptr %19, i64 4
  %35 = load i8, ptr %34, align 1, !tbaa !49
  %36 = icmp eq i8 %35, 45
  br i1 %36, label %37, label %47

37:                                               ; preds = %33
  %38 = tail call i64 @strlen(ptr noundef nonnull dereferenceable(1) %19)
  %39 = add i64 %38, -2
  %40 = tail call ptr @xmalloc(i64 noundef %39) #14
  store i8 45, ptr %40, align 1, !tbaa !49
  %41 = load i8, ptr %20, align 1, !tbaa !49
  %42 = getelementptr inbounds i8, ptr %40, i64 1
  store i8 %41, ptr %42, align 1, !tbaa !49
  %43 = getelementptr inbounds i8, ptr %40, i64 2
  %44 = getelementptr inbounds i8, ptr %19, i64 5
  %45 = add i64 %38, -4
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 1 %43, ptr nonnull align 1 %44, i64 %45, i1 false)
  %46 = tail call i64 @find_opt(ptr noundef nonnull %42, i32 noundef -1)
  tail call void @free(ptr noundef %40)
  br label %47

47:                                               ; preds = %23, %37, %33, %29, %25, %14
  %48 = phi i1 [ false, %37 ], [ true, %33 ], [ true, %29 ], [ true, %25 ], [ true, %14 ], [ true, %23 ]
  %49 = phi i64 [ %46, %37 ], [ %21, %33 ], [ %21, %29 ], [ %21, %25 ], [ %21, %14 ], [ %21, %23 ]
  %50 = icmp eq i64 %49, %12
  br i1 %50, label %51, label %53

51:                                               ; preds = %62, %57, %53, %47
  %52 = getelementptr inbounds i32, ptr %6, i64 %15
  store i32 0, ptr %52, align 4, !tbaa !53
  br label %70

53:                                               ; preds = %47
  %54 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %49, i32 4
  %55 = load i32, ptr %54, align 4, !tbaa !72
  %56 = icmp slt i32 %55, 0
  br i1 %56, label %51, label %57

57:                                               ; preds = %53
  %58 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %49, i32 5
  %59 = load i32, ptr %58, align 8, !tbaa !67
  %60 = and i32 %59, 33554432
  %61 = icmp eq i32 %60, 0
  br i1 %61, label %62, label %51

62:                                               ; preds = %57
  %63 = and i32 %59, 134217728
  %64 = icmp eq i32 %63, 0
  %65 = or i1 %48, %64
  br i1 %65, label %66, label %51

66:                                               ; preds = %62
  %67 = trunc i64 %49 to i32
  %68 = getelementptr inbounds i32, ptr %6, i64 %15
  store i32 %67, ptr %68, align 4, !tbaa !53
  %69 = or i32 %16, %67
  br label %70

70:                                               ; preds = %66, %51
  %71 = phi i32 [ %16, %51 ], [ %69, %66 ]
  %72 = add nuw nsw i64 %15, 1
  %73 = icmp eq i64 %72, %13
  br i1 %73, label %74, label %14, !llvm.loop !73

74:                                               ; preds = %70
  %75 = icmp eq i32 %71, 0
  br i1 %75, label %124, label %76

76:                                               ; preds = %74
  %77 = load ptr, ptr %1, align 8, !tbaa !38
  %78 = load ptr, ptr %77, align 8, !tbaa !38
  store ptr %78, ptr %8, align 8, !tbaa !38
  %79 = zext nneg i32 %3 to i64
  %80 = zext nneg i32 %3 to i64
  %81 = zext nneg i32 %3 to i64
  br label %82

82:                                               ; preds = %76, %116
  %83 = phi i64 [ 1, %76 ], [ %118, %116 ]
  %84 = phi i64 [ 2, %76 ], [ %119, %116 ]
  %85 = phi i32 [ 1, %76 ], [ %117, %116 ]
  %86 = getelementptr inbounds i32, ptr %6, i64 %83
  %87 = load i32, ptr %86, align 4, !tbaa !53
  %88 = icmp eq i32 %87, 0
  br i1 %88, label %109, label %89

89:                                               ; preds = %82
  %90 = add nuw nsw i64 %83, 1
  %91 = icmp ult i64 %90, %79
  %92 = trunc i64 %90 to i32
  br i1 %91, label %93, label %106

93:                                               ; preds = %89, %101
  %94 = phi i64 [ %102, %101 ], [ %84, %89 ]
  %95 = getelementptr inbounds i32, ptr %6, i64 %94
  %96 = load i32, ptr %95, align 4, !tbaa !53
  %97 = icmp eq i32 %96, 0
  br i1 %97, label %101, label %98

98:                                               ; preds = %93
  %99 = tail call fastcc zeroext i8 @cancel_option(i32 noundef %87, i32 noundef %96, i32 noundef %96), !range !74
  %100 = icmp eq i8 %99, 0
  br i1 %100, label %101, label %104

101:                                              ; preds = %93, %98
  %102 = add nuw nsw i64 %94, 1
  %103 = icmp eq i64 %102, %81
  br i1 %103, label %106, label %93, !llvm.loop !75

104:                                              ; preds = %98
  %105 = trunc i64 %94 to i32
  br label %106

106:                                              ; preds = %104, %101, %89
  %107 = phi i32 [ %92, %89 ], [ %105, %104 ], [ %3, %101 ]
  %108 = icmp eq i32 %107, %3
  br i1 %108, label %109, label %116

109:                                              ; preds = %106, %82
  %110 = load ptr, ptr %1, align 8, !tbaa !38
  %111 = getelementptr inbounds ptr, ptr %110, i64 %83
  %112 = load ptr, ptr %111, align 8, !tbaa !38
  %113 = sext i32 %85 to i64
  %114 = getelementptr inbounds ptr, ptr %8, i64 %113
  store ptr %112, ptr %114, align 8, !tbaa !38
  %115 = add nsw i32 %85, 1
  br label %116

116:                                              ; preds = %109, %106
  %117 = phi i32 [ %115, %109 ], [ %85, %106 ]
  %118 = add nuw nsw i64 %83, 1
  %119 = add nuw nsw i64 %84, 1
  %120 = icmp eq i64 %118, %80
  br i1 %120, label %121, label %82, !llvm.loop !76

121:                                              ; preds = %116
  %122 = icmp eq i32 %117, %3
  br i1 %122, label %124, label %123

123:                                              ; preds = %121
  store i32 %117, ptr %0, align 4, !tbaa !53
  store ptr %8, ptr %1, align 8, !tbaa !38
  br label %125

124:                                              ; preds = %2, %121, %74
  tail call void @free(ptr noundef %8)
  br label %125

125:                                              ; preds = %124, %123
  tail call void @free(ptr noundef %6)
  ret void
}

declare ptr @xmalloc(i64 noundef) local_unnamed_addr #3

; Function Attrs: mustprogress nofree nounwind willreturn memory(argmem: read)
declare i64 @strlen(ptr nocapture noundef) local_unnamed_addr #9

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias nocapture writeonly, ptr noalias nocapture readonly, i64, i1 immarg) #11

; Function Attrs: mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite)
declare void @free(ptr allocptr nocapture noundef) local_unnamed_addr #12

; Function Attrs: cold nofree nosync nounwind memory(none) uwtable
define internal fastcc zeroext i8 @cancel_option(i32 noundef %0, i32 noundef %1, i32 noundef %2) unnamed_addr #13 !prof !37 {
  br label %4

4:                                                ; preds = %10, %3
  %5 = phi i32 [ %1, %3 ], [ %8, %10 ]
  %6 = sext i32 %5 to i64
  %7 = getelementptr inbounds [0 x %struct.cl_option], ptr @cl_options, i64 0, i64 %6, i32 4
  %8 = load i32, ptr %7, align 4, !tbaa !72
  %9 = icmp eq i32 %8, %0
  br i1 %9, label %12, label %10

10:                                               ; preds = %4
  %11 = icmp eq i32 %8, %2
  br i1 %11, label %12, label %4

12:                                               ; preds = %10, %4
  %13 = phi i8 [ 1, %4 ], [ 0, %10 ]
  ret i8 %13
}

attributes #0 = { cold inlinehint nofree nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #1 = { nofree nounwind "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #2 = { cold inlinehint nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #4 = { cold inlinehint mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { cold inlinehint mustprogress nofree nounwind willreturn memory(read) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { cold inlinehint mustprogress nofree nounwind willreturn uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { mustprogress nofree nounwind willreturn "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nofree nounwind memory(read, inaccessiblemem: none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { mustprogress nofree nounwind willreturn memory(argmem: read) "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { cold nounwind uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #12 = { mustprogress nounwind willreturn allockind("free") memory(argmem: readwrite, inaccessiblemem: readwrite) "alloc-family"="malloc" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { cold nofree nosync nounwind memory(none) uwtable "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { nounwind }

!llvm.module.flags = !{!0, !1, !2, !3, !4, !33}
!llvm.ident = !{!36}

!0 = !{i32 1, !"wchar_size", i32 4}
!1 = !{i32 8, !"PIC Level", i32 2}
!2 = !{i32 7, !"PIE Level", i32 2}
!3 = !{i32 7, !"uwtable", i32 2}
!4 = !{i32 1, !"ProfileSummary", !5}
!5 = !{!6, !7, !8, !9, !10, !11, !12, !13, !14, !15}
!6 = !{!"ProfileFormat", !"InstrProf"}
!7 = !{!"TotalCount", i64 25970300442}
!8 = !{!"MaxCount", i64 499227316}
!9 = !{!"MaxInternalCount", i64 499227316}
!10 = !{!"MaxFunctionCount", i64 269079181}
!11 = !{!"NumCounts", i64 219814}
!12 = !{!"NumFunctions", i64 12846}
!13 = !{!"IsPartialProfile", i64 0}
!14 = !{!"PartialProfileRatio", double 0.000000e+00}
!15 = !{!"DetailedSummary", !16}
!16 = !{!17, !18, !19, !20, !21, !22, !23, !24, !25, !26, !27, !28, !29, !30, !31, !32}
!17 = !{i32 10000, i64 499227316, i32 1}
!18 = !{i32 100000, i64 183919233, i32 10}
!19 = !{i32 200000, i64 63966136, i32 32}
!20 = !{i32 300000, i64 31763078, i32 90}
!21 = !{i32 400000, i64 20117281, i32 196}
!22 = !{i32 500000, i64 11046006, i32 375}
!23 = !{i32 600000, i64 6386181, i32 684}
!24 = !{i32 700000, i64 3816210, i32 1202}
!25 = !{i32 800000, i64 1875647, i32 2153}
!26 = !{i32 900000, i64 635998, i32 4611}
!27 = !{i32 950000, i64 320174, i32 7413}
!28 = !{i32 990000, i64 82126, i32 13176}
!29 = !{i32 999000, i64 12347, i32 18728}
!30 = !{i32 999900, i64 1133, i32 23724}
!31 = !{i32 999990, i64 83, i32 29864}
!32 = !{i32 999999, i64 20, i32 34832}
!33 = !{i32 5, !"CG Profile", !34}
!34 = distinct !{!35}
!35 = !{ptr @find_opt, ptr @strncmp, i64 42}
!36 = !{!"Ubuntu clang version 18.1.8 (++20240731024944+3b5b5c1ec4a3-1~exp1~20240731145000.144)"}
!37 = !{!"function_entry_count", i64 0}
!38 = !{!39, !39, i64 0}
!39 = !{!"any pointer", !40, i64 0}
!40 = !{!"omnipotent char", !41, i64 0}
!41 = !{!"Simple C/C++ TBAA"}
!42 = !{!43, !39, i64 8}
!43 = !{!"_IO_FILE", !44, i64 0, !39, i64 8, !39, i64 16, !39, i64 24, !39, i64 32, !39, i64 40, !39, i64 48, !39, i64 56, !39, i64 64, !39, i64 72, !39, i64 80, !39, i64 88, !39, i64 96, !39, i64 104, !44, i64 112, !44, i64 116, !45, i64 120, !46, i64 128, !40, i64 130, !40, i64 131, !39, i64 136, !45, i64 144, !39, i64 152, !39, i64 160, !39, i64 168, !39, i64 176, !45, i64 184, !44, i64 192, !40, i64 196}
!44 = !{!"int", !40, i64 0}
!45 = !{!"long", !40, i64 0}
!46 = !{!"short", !40, i64 0}
!47 = !{!43, !39, i64 16}
!48 = !{!"branch_weights", i32 2000, i32 1}
!49 = !{!40, !40, i64 0}
!50 = !{!43, !39, i64 40}
!51 = !{!43, !39, i64 48}
!52 = !{!43, !44, i64 0}
!53 = !{!44, !44, i64 0}
!54 = distinct !{!54, !55, !56}
!55 = !{!"llvm.loop.mustprogress"}
!56 = !{!"llvm.loop.unroll.disable"}
!57 = !{!"function_entry_count", i64 4}
!58 = !{!"branch_weights", i32 127, i32 1}
!59 = !{!60, !40, i64 18}
!60 = !{!"cl_option", !39, i64 0, !39, i64 8, !46, i64 16, !40, i64 18, !44, i64 20, !44, i64 24, !39, i64 32, !44, i64 40, !44, i64 44}
!61 = !{!60, !39, i64 0}
!62 = !{!"branch_weights", i32 23, i32 15}
!63 = !{!"branch_weights", i32 1089, i32 127}
!64 = distinct !{!64, !55, !56}
!65 = !{!"branch_weights", i32 4, i32 0}
!66 = !{!"branch_weights", i32 3, i32 1}
!67 = !{!60, !44, i64 24}
!68 = !{!"branch_weights", i32 0, i32 1}
!69 = !{!"branch_weights", i32 0, i32 4}
!70 = !{!60, !46, i64 16}
!71 = distinct !{!71, !55, !56}
!72 = !{!60, !44, i64 20}
!73 = distinct !{!73, !55, !56}
!74 = !{i8 0, i8 2}
!75 = distinct !{!75, !55, !56}
!76 = distinct !{!76, !55, !56}
